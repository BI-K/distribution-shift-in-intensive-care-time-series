#!/bin/bash
. ./venv/bin/activate
python main.py --phase all --exp_name PHD_cardiac_surgery_cleaned_nbp_mean_to_no_cardiac_surgery_cleaned_nbp_mean_CNN_NO_ADAPT --da_method NO_ADAPT --dataset PHD --backbone CNN
