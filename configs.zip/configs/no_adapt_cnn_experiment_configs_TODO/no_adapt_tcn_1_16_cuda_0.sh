#!/bin/bash
. ./venv/bin/activate
python main_sweep.py --dataset PHD --da_method NO_ADAPT --backbone TCN --num_runs 1 --num_sweeps 16 --device cuda:0
