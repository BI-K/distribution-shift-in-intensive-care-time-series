venv/Scripts/activate
python ./scripts/create_dataset.py --config ./configs/create/ventilation_with_start_end.json
python ./scripts/split_dataset.py --config ./configs/split/ventilation_with_start_end.json
python ./scripts/transform_input_data_to_expected_format_ADATime.py --path ./outputs/split/ventilation/split_data
# copy file to Algorithm2Domain so configs can be fed to wandb
mkdir -p ./Algorithm2Domain/Evaluation_Framework/ADATime_data/PHD/details/ventilation/
Copy-Item -Path ./configs/split/ventilation_with_start_end.json -Destination ./Algorithm2Domain/Evaluation_Framework/ADATime_data/PHD/details/ventilation/
Rename-Item -Path ./Algorithm2Domain/Evaluation_Framework/ADATime_data/PHD/details/ventilation/ventilation_with_start_end.json -NewName create_config.json
Copy-Item -Path ./configs/create/ventilation_with_start_end.json -Destination ./Algorithm2Domain/Evaluation_Framework/ADATime_data/PHD/details/ventilation/
Rename-Item -Path ./Algorithm2Domain/Evaluation_Framework/ADATime_data/PHD/details/ventilation/ventilation_with_start_end.json -NewName split_config.json
Copy-Item -Path ./configs/base_config.json -Destination ./Algorithm2Domain/Evaluation_Framework/ADATime_data/PHD/details/ventilation/