venv/Scripts/activate
python ./scripts/create_dataset.py --config ./configs/create/no_vasopressors_with_start_end.json
python ./scripts/split_dataset.py --config ./configs/split/no_vasopressors_with_start_end.json
python ./scripts/transform_input_data_to_expected_format_ADATime.py --path ./outputs/split/no_vasopressors/split_data
# copy file to Algorithm2Domain so configs can be fed to wandb
mkdir -p ./Algorithm2Domain/Evaluation_Framework/ADATime_data/PHD/details/no_vasopressors/
Copy-Item -Path ./configs/split/no_vasopressors_with_start_end.json -Destination ./Algorithm2Domain/Evaluation_Framework/ADATime_data/PHD/details/no_vasopressors/
Rename-Item -Path ./Algorithm2Domain/Evaluation_Framework/ADATime_data/PHD/details/no_vasopressors/no_vasopressors_with_start_end.json -NewName create_config.json
Copy-Item -Path ./configs/create/no_vasopressors_with_start_end.json -Destination ./Algorithm2Domain/Evaluation_Framework/ADATime_data/PHD/details/no_vasopressors/
Rename-Item -Path ./Algorithm2Domain/Evaluation_Framework/ADATime_data/PHD/details/no_vasopressors/no_vasopressors_with_start_end.json -NewName split_config.json
Copy-Item -Path ./configs/base_config.json -Destination ./Algorithm2Domain/Evaluation_Framework/ADATime_data/PHD/details/no_vasopressors/