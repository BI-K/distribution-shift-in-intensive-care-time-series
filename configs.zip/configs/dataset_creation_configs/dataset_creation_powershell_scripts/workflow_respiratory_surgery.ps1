venv/Scripts/activate
python ./scripts/create_dataset.py --config ./configs/create/respiratory_surgery_with_start_end.json
python ./scripts/split_dataset.py --config ./configs/split/respiratory_surgery_with_start_end.json
python ./scripts/transform_input_data_to_expected_format_ADATime.py --path ./outputs/split/respiratory_surgery/split_data
# copy file to Algorithm2Domain so configs can be fed to wandb
mkdir -p ./Algorithm2Domain/Evaluation_Framework/ADATime_data/PHD/details/respiratory_surgery/
Copy-Item -Path ./configs/split/respiratory_surgery_with_start_end.json -Destination ./Algorithm2Domain/Evaluation_Framework/ADATime_data/PHD/details/respiratory_surgery/
Rename-Item -Path ./Algorithm2Domain/Evaluation_Framework/ADATime_data/PHD/details/respiratory_surgery/respiratory_surgery_with_start_end.json -NewName create_config.json
Copy-Item -Path ./configs/create/respiratory_surgery_with_start_end.json -Destination ./Algorithm2Domain/Evaluation_Framework/ADATime_data/PHD/details/respiratory_surgery/
Rename-Item -Path ./Algorithm2Domain/Evaluation_Framework/ADATime_data/PHD/details/respiratory_surgery/respiratory_surgery_with_start_end.json -NewName split_config.json
Copy-Item -Path ./configs/base_config.json -Destination ./Algorithm2Domain/Evaluation_Framework/ADATime_data/PHD/details/respiratory_surgery/