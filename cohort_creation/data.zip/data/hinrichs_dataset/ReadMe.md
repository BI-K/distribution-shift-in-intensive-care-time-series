# Hinrichs Dataset
Contains selected records for evaluation of the Hinrichs base model from the paper: 
Hinrichs N, Roeschl T, Lanmueller P, Balzer F, Eickhoff C, O’Brien B, et al. Short-term vital parameter forecasting in the intensive care unit: A benchmark study leveraging data from patients after cardiothoracic surgery. Barage S, editor. PLOS Digit Health. 2024 Sep 12;3(9):e0000598. 

The records were selected using <..\\..\\hinrichs_base_model_dataset_creation>.
The contain subject_ids and record_ids of records that contain:
- signals: CVP, HR, NBPSys, NBPDias, NBPMean, SpO2
- minimum duration of 65 minutes

Each file contains a list of dictionaries of the following format:
```
{"subject": "p00/p000214/", "record_id": "p000214-2188-10-24-16-23n"}
```

## Structure
- valid_records_hinrichs_base_model.json
    - all records that fit the specification above
        - signals: CVP, HR, NBPSys, NBPDias, NBPMean, SpO2
        - minimum duration of 65 minutes
    - number of subjects: 887
    - number of records: 1508
    - total duration of records: 4318.5 days

- translated_valid_records_with_cardiac_surgery_during_icu_stay_hinrichs_base_model.json
    - all records that fit the specification above
        - signals: CVP, HR, NBPSys, NBPDias, NBPMean, SpO2
        - minimum duration of 65 minutes
    - all corresponding subject_ids had a cardiac surgery during a stay with at least on erecording during that
        - all corresponding subject_ids have an entry in the mimic iii PROCEDURES_ICD table, with an icd9 code within 35 - 39
    - all records that started recording during the stay associated with the cardiac surgery in an ICU (with a margin of 2 hours)
    - number of subjects: 756 (meaning: 131 patients without recording during their stay with caridac surgery)
    - number of records: 1234 (meanning: 305 recordings that were not recorded during a stay with cardiac surgery)
    - total duration of records: 3642.4 days


## Interesting Noten on the MIMIC III matched waveform database
Patients that have records for CVP and HR only record blood pressure in the form of NBPSys, NBPDias, NBPMean.


