# Data Description

## Strcuture

- mimic3wdb-matched_numerics_signals_duration.csv 
    - information on numerics waveforms, includes information on subject, record, list of signals recorded in the recording, duration in seconds, sampling frequency
    - created by ..exploration_mimic_iii_macthed_waveform.ipynb
- subject_signals_map_.csv 
    - subject-wise information collected on all waveforms (including numerics): subject, list of signals
    - first part of analysis
    - created by ..get_subject_and_signas_map.py
- subject_signals_map_2.csv 
    - subject-wise information collected on all waveforms (including numerics): subject, list of signals
    - second and last part of analysis
    - created by ..get_subject_and_signas_map.py